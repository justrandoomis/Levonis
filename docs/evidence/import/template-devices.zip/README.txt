LEVONIS — قالب استيراد المنتجات (الأجهزة / Devices)

كيف يعمل الملف
--------------
كل منتج يمتد على عدة أسطر، والعمود الأول row_type يحدد نوع السطر:

  product   المنتج نفسه (سطر واحد لكل منتج)
  option    قيمة واحدة من مجموعة خيارات
  color     لون واحد، مع روابطه بالخيارات
  image     صورة واحدة

تُربط الأسطر بالمنتج عبر العمود key — وهو SKU المنتج أو الـ slug.
كرّر نفس القيمة في كل أسطر المنتج.

قواعد مهمة
----------
* الإدخال بالإنجليزية فقط. الترجمة إلى العربية والكردية تتم محليًا على الخادم
  بعد الاستيراد، بلا أي ذكاء اصطناعي وبلا أي اتصال خارجي.
* الأسعار أرقام صحيحة بالدينار. الترتيب المطلوب: PRO ≤ PRIME ≤ الاعتيادي،
  ولا يجوز أن يساوي سعر البيع التكلفة.
* روابط اللون تُكتب Group:Value مفصولة بـ | — داخل المجموعة «أو»، وبين
  المجموعات «و». لون بلا روابط يظهر مع كل الخيارات.
* صورة رئيسية واحدة فقط لكل منتج. إن لم تحدد واحدة تُعتمد الأولى.
* عمود image إمّا اسم ملف داخل مجلد images/ في هذا الـ ZIP، أو رابط مباشر
  إلى ملف صورة. لا يُقرأ من صفحات المنتجات إطلاقًا.
* المعاينة لا تكتب أي شيء في قاعدة البيانات. الكتابة تحدث فقط بعد التأكيد،
  وإعادة التأكيد بنفس import_id لا تكرر شيئًا.

الأعمدة الخاصة بهذا القسم
-------------------------
  spec.technology — التقنية / Technology
  spec.model — الموديل / Model
  spec.build_volume (mm) — حجم الطباعة / Build volume
  spec.print_speed (mm/s) — السرعة / Print speed
  spec.resolution — الدقة / Resolution
  spec.nozzle (mm) — القطر / النوزل / Nozzle diameter
  spec.supported_materials — الأنظمة والمواد المتوافقة / Supported materials
  spec.power (W) — الطاقة / Power
  spec.dimensions (mm) — الأبعاد / Dimensions
  spec.weight (kg) — الوزن / Weight
  spec.connectivity — الاتصال / Connectivity
  spec.compatibility — التوافق / Compatibility
  spec.warranty (months) — الضمان / Warranty
  spec.in_the_box — محتويات العلبة / In the box
  spec.nozzle_temp_max (°C) — أقصى حرارة نوزل / Max nozzle temperature
  spec.bed_temp_max (°C) — أقصى حرارة سرير / Max bed temperature
  spec.extruders — عدد الباثقات / Extruders
  spec.enclosed — هيكل مغلق / Enclosed
  spec.auto_leveling — التسوية التلقائية / Auto leveling
  spec.multi_color — دعم تعدد الألوان / Multi-colour support

الملفات
-------
  data.csv     البيانات (UTF-8، مفصولة بفواصل)
  images/      ضع هنا الصور المذكورة في أعمدة image
  README.txt   هذا الملف
